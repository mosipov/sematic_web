package extrasktion_zoo;

public class Zoohandlung {
	
	
	private String stadtbezirk;
	private char anzahl_zoo;
	
	Zoohandlung(){
		this.stadtbezirk = "";
		this.anzahl_zoo = 0;
	}
	
	Zoohandlung(String stadtbezirk, char anzahl_zoo){
		this.stadtbezirk = stadtbezirk;
		this.anzahl_zoo = anzahl_zoo;
	}
	
	public String getStreet(){
		return this.stadtbezirk; 
	}
	
	public char getCount(){
		return this.anzahl_zoo; 
	}

}
