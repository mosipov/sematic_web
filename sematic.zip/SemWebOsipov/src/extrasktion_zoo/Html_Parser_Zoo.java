package extrasktion_zoo;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import com.google.gson.Gson;
import org.jsoup.nodes.Element;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class Html_Parser_Zoo {
	
	
	public static void main(String[] args) throws IOException {
		
		Document doc = Jsoup.connect("https://meinleipzig.eu/Einzelhandel-und-Einkaufen/Zoohandlung").get();
		
		Gson gson = new Gson();
		
		Zoohandlung zoo; 
		List<Zoohandlung> zoohandlungen = new ArrayList<>();
		
		
		
		
		
		Elements elemente = doc.select("div#Stadtteile").get(0).getElementsByTag("a");
		String output ="";
		
		for(Element el: elemente){	
			//output = output+el.html()+": "+el.attr("title").charAt(0)+"\n";
			
			zoohandlungen.add(new Zoohandlung(el.html(), el.attr("title").charAt(0) ));
		}
		
		 String json = gson.toJson(zoohandlungen);
	        System.out.println(json);
		
		
	     try (FileWriter writer = new FileWriter("D:\\staff.json")) {

	            gson.toJson(zoohandlungen, writer);

	      } catch (IOException e) {
	            e.printStackTrace();
	     }
		
		
		
		
		
	}
	
	
	
	

}
